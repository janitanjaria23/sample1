import java.io.*;
class decode
{
	public static void main(String args[])throws Exception
	{
		DataInputStream dis=new DataInputStream(System.in);
		String m="", ec="", c="";
		int n=0;
		double y=0;
		System.out.print("Enter the Code: ");
		ec=dis.readLine().trim();
		for(int i=ec.length()-1;; i--)
			if(ec.charAt(i)!=' ')
				c=String.valueOf(ec.charAt(i)).concat(c);
			else
			{
				n=Integer.parseInt(c);
				c="";
				y=Math.sqrt(n);
				ec=ec.substring(0,i+1);
				break;
			}
		for(int i=0; i<ec.length(); i++)
		{
			if(ec.charAt(i)!=' ')
				c=c.concat(String.valueOf(ec.charAt(i)));
			else
			{
				n=Integer.parseInt(c);
				c="";
				n/=y;
				m=m.concat(String.valueOf((char)n));
			}			
		}
		System.out.println(m);
	}
}