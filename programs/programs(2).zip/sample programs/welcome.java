
class welcome 
{
	public static void main(String args [])
	{
		System.out.println("welcome to java");
		System.out.println("udit");
		
	}
}
