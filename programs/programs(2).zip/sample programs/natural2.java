import java.util.*;

class natural2
{
		public static void main(String abc[])
		{
			Scanner sc=new Scanner(System.in);
			int n=0,s=0;
		
				System.out.print("enter number: ");
				n=sc.nextInt();
			s=n(n+1)/2;
			System.out.println(s);
		}
}