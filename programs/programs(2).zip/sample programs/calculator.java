import java.io.*;

class calculator
{
    public static void main(String abc[])throws exception
    {
        DataInputStream dis=new DataInputStream(System.in);
        char t=' ';
        double n=0,a=0,s=0;
