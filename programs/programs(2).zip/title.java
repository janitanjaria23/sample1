class title
{    
    void title1()
    {
        System.out.println("  **   **\t\t*******\t\t*******\t\t*******\t\t*******");
        System.out.println("  *** ***\t\t*******\t\t*******\t\t*******\t\t*******");
        System.out.println("  ** * **\t\t**   **\t\t**     \t\t   **  \t\t**     ");
        System.out.println("  **   **\t\t**   **\t\t**     \t\t   **  \t\t**     ");
        System.out.println("  **   **\t\t*******\t\t**   **\t\t   **  \t\t**     ");
        System.out.println("  **   **\t\t*******\t\t**   **\t\t   **  \t\t**     ");
        System.out.println("  **   **\t\t**   **\t\t*******\t\t*******\t\t*******");
        System.out.println("  **   **\t\t**   **\t\t*******\t\t*******\t\t*******");
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("     \t*******\t*******\t**   **\t*******\t*******\t*******");
        System.out.println("     \t*******\t*******\t**   **\t*******\t*******\t*******");
        System.out.println("     \t**     \t**   **\t**   **\t**   **\t**   **\t**     ");
        System.out.println("     \t*******\t**   **\t**   **\t**   **\t*******\t*******");
        System.out.println("     \t*******\t**   **\t**   **\t*******\t*******\t*******");
        System.out.println("     \t     **\t**  * *\t**   **\t*******\t****   \t**     ");
        System.out.println("     \t*******\t**** * \t*******\t**   **\t** **  \t*******");
        System.out.println("     \t*******\t***** *\t*******\t**   **\t**  ** \t*******");



    }
}