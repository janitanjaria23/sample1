class darshil
{
    public static void main(String args[])throws Exception
    {        
        project pr=new project();
        pr.title();
        Thread.sleep(500);
        while(true)      	
        	pr.menu();
    }
}
