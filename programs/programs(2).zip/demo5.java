import java.util.*;
class demo5
{
    public static void main(String args[])throws Exception
    {
        //inventory in=new inventory();
        //in.menu();
	  fibbo f=new fibbo(); 
      String x[]= {"A","b"};
        f.main(x);
    }
}

     
