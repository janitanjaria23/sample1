class bat
{
    public static void main(String args[])throws Exception
    {
        for(;;)
        {
            for(int i=0;i<8;i++)
                System.out.println((char)7);
            Thread.sleep(30000);
        }
    }
}
