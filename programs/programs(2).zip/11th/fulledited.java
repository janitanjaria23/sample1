Attach java.util.*;
Attach java.io.*;
Program inventory
Begin
    var ino,des : String; 

Program inventory
Begin
    var ino,des : String;
    var qoh,rol,roq : Integer;
    var a,b: boolean;
   
    non returning method "menu  throws Exception"
    Begin
        //premenu  ;
        var ch,ch1,ch4,ne : Integer;
        var c: character;
        var in,re : String;
        var v,v1 : boolean ;
        
        object of BufferedReader  := br;
        for ;; 
        Begin
        Displayln "Select any one of the following options: " ;
        Displayln "1.Modify Records" ;
        Displayln "2.Sell Products" ;
        Displayln "3.Veiw Records" ;
        Displayln "4.Search for Records" ;
        Displayln "5.Exit" ;
        
        while ch<1 || ch>5   do
        Begin
            Display "Enter your choice: " ;
            Input ch  := Integer.parseInt br.readLine  .trim   ;

        end;
        
        for int i := 1 to 40  next 1  do
            Displayln  ;
        if ch  :=1 
        Begin
            Displayln "Select any one of the following options: " ;
            Displayln "1.Add Records" ;
            Displayln "2.Delete Records" ;
            Displayln "3.Change Re-Order Quantity" ;
            Displayln "4.Change Re-Order Level" ;
            Displayln "5.Check Quantity On Hand with Re-Order Level" ;
            
            while ch1<1 || ch1>5   do
            Begin
                Display "Enter your choice: " ;
                Input ch1 :=Integer.parseInt br.readLine  .trim   ;
            end;
            
            for int i := 1 to 40  next 1  do
                Displayln  ;
            if ch1  :=1 
            Begin
                for ;; 
                Begin
                    input  ;
                    write  ;
                    sort inoc   ;
                    Display "Do you have more records to enter: " ;
                    Input c :=br.readLine  .trim  .charAt 0 ;
                    if c  :='n' || c  :='N' 
                        break;
                end;
                sort inoc   ;
            end;
            if ch1  :=2 
            Begin
                for ;; 
                Begin
                    Display "Enter the item number you want to delete: " ;
                    Input in :=br.readLine  .trim  ;
                    v1 :=validate in ;
                    if v1 
                    Begin
                        for ;; 
                        Begin
                            v :=true;
                            Display "Enter the reason for deletion: " ;
                            Input re :=br.readLine  .trim  ;
                            if re.length  >15 
                                v :=false;
                            for int i := 0 to length of re  next 1  do
                            Begin       
                                c :=re.charAt i ;
                                if !  c> :='A' && c< :='Z'  ||  c  :=' '  ||  c> :='a' && c< :='z'  ||  c>'0' && c< :='9'   
                                    v :=false;
                            end;
                            if v 
                                break;
                        end;
                        re :=spaces re," " .trim  ;
                        re :=re.substring 0,re.length  -2 ;
                        delete in,re ;
                        break;
                    end;
                    else
                        Displayln "Invalid Item Number!" ;
                end;
            end;
            if ch1  :=3 
            Begin
                for ;; 
                Begin
                    Display "Enter the item number for changing ROQ: " ;
                    Input in :=br.readLine  .trim  ;
                    v1 :=validate in ;
                    if v1 
                        break;
                    else
                        Displayln "Invalid Item Number!" ;
                end;
                do
                Begin
                    Display "Enter the new ROQ: " ;
                    Input ne :=Integer.parseInt br.readLine  .trim   ;
                end;while ne<2 ;
                update in,2,ne ;
            end;
            if ch1  :=4 
            Begin
                for ;; 
                Begin
                    Display "Enter the item number for changing ROL: " ;
                    Input in :=br.readLine  .trim  ;
                    v1 :=validate in ;
                    if v1 
                        break;
                    else
                        Displayln "Invalid Item Number!" ;
                end;
                while ne<2   do
                Begin
                    Display "Enter the new ROL: " ;
                    Input ne :=Integer.parseInt br.readLine  .trim   ;
                end;
                update in,1,ne ;
            end;
            if ch1  :=5 
            Begin
                rolc inoc   ;
            end;
        end;
        if ch  :=2 
        Begin
            File f1 :=new File "master.dat" ;
            if f1.exists   
            Begin
                sell  ;
                sort inoc   ;
            end;
        end;
        if ch  :=4 
        Begin
            File f1 :=new File "master.dat" ;
            if f1.exists   
            Begin
                    Display "Enter the item number for searching: " ;
                    Input in :=br.readLine  .trim  ;
                    v1 :=validate in ;
                    if v1 
                        Displayln "Record Found!" ;
                    else
                        Displayln "Record Not Found!" ;
            end;
        end;
        if ch  :=3 
        Begin
            Displayln "Select any one of the following options: " ;

            Displayln "1.Master File" ;
            Displayln "2.Sales File" ;
            Displayln "3.Reorder File" ;
            Displayln "4.Deletion File" ;

            while ch4<1 || ch4>4   do
            Begin
                Display "Enter your choice: " ;
                Input ch4 :=Integer.parseInt br.readLine  .trim   ;
            end;
            
            for int i := 1 to 40  next 1  do
                Displayln  ;
            read ch4 ;
        end;
        if ch  :=5 
            System.exit 0 ;
        end;
    end;

    // accepts data from user and stores it in properties
    // --------------------------------------------------

    Non returning method input  throws Exception
    Begin
        Object of class BufferedReader  := br;
        var v :boolean;
        var ctr1: Integer;
        var c : Character;
        for ;; 
        Begin
            v :=true;
            ctr1 :=0;
            Display "Enter Item Number eg. I001 : " ;
            Input ino :=br.readLine  .trim  .toUpperCase  ;
            if ino.length  ! :=4 
            Begin
                v :=false;
                continue;
            end;
            if ino.charAt 0 ! :='I' && ino.charAt 0 ! :='i' 
                v :=false;
            for int i := 1 to 4  next 1  do
            Begin
                if ! ino.charAt i > :='0' && ino.charAt i < :='9'  
                    v :=false;
            end;
            if ! validate ino   && v 
                break;
        end;
        for ;; 
        Begin
            v :=true;
            ctr1 :=0;
            Display "Enter the Description: " ;
            Input des :=br.readLine  .trim  ;
            if des.length  >15 
                v :=false;
            for int i := 0 to length of des  next 1  do
            Begin
                c :=des.charAt i ;
                if !  c> :='A' && c< :='Z'  ||  c> :='a' && c< :='z'  ||  c  :=' '  ||  c>'0' && c< :='9'   
                    v :=false;
                if c> :='0' && c< :='9' 
                    ctr1 :=ctr1+1;
            end;
            if ctr1  :=des.length   
            Begin
                v :=false;
            end;
            if v 
                break;
        end;
        des :=spaces des," " .trim  ;
        des :=des.substring 0,des.length  -2 ;
        var t1: String;
        ctr1 :=0;
        while qoh<0   do
        Begin
            Display "Enter Quantity on Hand: " ;
            Input t1 :=br.readLine  .trim  ;
            
            qoh :=Integer.parseInt t1 ;
        end;
        
        ctr1 :=0;
        
        while rol<2   do
        Begin
            Display "Enter Re-order level: " ;
            Input t1 :=br.readLine  .trim  ;
            ctr1 :=0;
            for int i := 0 to length of t1  next 1  do
            Begin
                c :=t1.charAt i ;
                if c> :='0' && c< :='9' 
                    ctr1 :=ctr1+1;
            end;
            if ! ctr1  :=t1.length    
            Begin
                continue;
            end;
            rol :=Integer.parseInt t1 ;
        end;
        
        ctr1 :=0;
        while roq<2   do
        Begin
            Display "Enter Re-order quantity: " ;
            Input t1 :=br.readLine  .trim  ;
            ctr1 :=0;
            for int i := 0 to length of t1  next 1  do 
            Begin
                c :=t1.charAt i ;
                if c> :='0' && c< :='9' 
                    ctr1 := ctr1+1;
            end;
            if ! ctr1  :=t1.length    
            Begin
                continue;
            end;
            roq :=Integer.parseInt t1 ;
        end;
    end;

    // checks weather or not the item numer exists in master file or not
    //------------------------------------------------------------------

    Non returning parameterised method validate String in throws Exception of type boolean
    Begin
        var v :boolean;
        var to,ctr : Integer;
        File f :=new File "master.dat" ;
        if f.exists   
        Begin
            FileReader fr :=new FileReader "master.dat" ;
            Object of class StreamTokenizer := st;
            st.eolIsSignificant true ;
            while to! :=-1 
            Begin
                to :=st.nextToken  ;
                if in.equalsIgnoreCase st.sval  
                    v :=true;
                to :=st.nextToken  ;
                to :=st.nextToken  ;
                to :=st.nextToken  ;
                while to! :=10 && to! :=-1 
                Begin
                    to :=st.nextToken  ;
                end;
            end;
            fr.close  ;
        end;
        else
            v :=false;
        return v;
    end;

    // reads the file and prints the records
    // -------------------------------------

    Non returning parameterised method  read int x throws Exception
    Begin
        var s : String;
        if x  :=1 
            s :="master.dat";
        if x  :=2 
            s :="sell.dat";
        if x  :=3 
            s :="reorder.dat";
        if x  :=4 
            s :="deleted.dat";
        File f :=new File s ;
        if  f.exists    
        Begin
            var to : Integer;
            String[] ou;
            FileReader fr :=new FileReader s ;
            Object of class StreamTokenizer := st;
            st.eolIsSignificant true ;
            if x  :=1 
            Begin
                Displayln "ino\tdes\troq\tqoh\trol" ;
            end;
            if x  :=4 
            Begin
                Displayln "dat\tino\tdes\tres" ;
            end;

                while to! :=-1 
                Begin
                    if to  :=-3 
                    Begin
                        if x  :=1 || x  :=3 
                            if ctr  :=1 
                                Display st.sval+"\t" ;
                            else
                            Begin
                                ou :=st.sval.split "00" ;
                                for int i := 0 to length of ou  next 1  do 
                                    Display ou[i]+" " ;
                                Display "\t" ;
                            end;
                        else
                            if ctr  :=2 
                                Display st.sval+"\t" ;
                            else
                            Begin
                                ou :=st.sval.split "00" ;
                                for int i := 0 to length of ou  next 1  do 
                                    Display ou[i]+" " ;
                                Display "\t" ;
                            end;
                        ctr :=ctr+1;
                    end;
                    if to  :=-2 
                    Begin
                        Display  int st.nval+"\t" ;
                        ctr := ctr+1;
                    end;
                    if to  :=10 
                    Begin
                        ctr := ctr+1;
                        if x  :=1 
                            if ctr  :=7 
                            Begin
                                Displayln  ;
                                ctr :=1;
                            end;
                            else
                                ctr := ctr-1;
                        if x  :=2 
                            if ctr  :=5 
                            Begin
                                Displayln  ;
                                ctr :=1;
                            end;
                            else
                                ctr := ctr-1;
                        if x  :=3 
                            if ctr  :=6 
                            Begin
                                Displayln  ;
                                ctr :=1;
                            end;
                            else
                                ctr := ctr-1;
                        if x  :=4 
                            if ctr  :=6 
                            Begin
                                Displayln  ;
                                ctr :=1;
                            end;
                            else
                                ctr := ctr-1;
                    end;
                    to :=st.nextToken  ;
                end;
            fr.close  ;
        end;   
    end;

    // writes the properties into master file
    // --------------------------------------

    Non-returning method write  throws Exception
    Begin
        Object of FileOutputStream  := fos"master.dat",true ;
        Object of BufferedOutputStream := bos fos ;
        Object of DataOutputStream  := dos bos ;
        Write to File  ino ;
        Write to File  des ;
        Write to File  String.valueOf roq  ;
        Write to File  String.valueOf qoh  ;
        Write to File  String.valueOf rol  ;
        Write to File  "\n" ;

        close dos  ;
        close bos  ;
        close fos  ;
    end;

    // change spaces to 00 using string tokenizer
    //-------------------------------------------

    Returning-Parameterised method spaces String d,String c  of type String 
    Begin
        var t :String;
        Object of class StreamTokenizer := st  d,c,true ;
        while st.hasMoreTokens     
        Begin
            if c.equals " "  
                t+ :=st.nextToken  +"00";
            if c.equals "00"  
                t+ :=st.nextToken  +" ";
        end;
        //Displayln d+"\n"+t ;
        return t;
    end;


    Non-Returning Parameterised method  repor int m,int da  throws Exception
    Begin
        var ctr1 : Integer;
        var ctr,nu,str,to,k : Integer;

            FileReader fr :=new FileReader "master.dat" ;
           Object of class StreamTokenizer := st  fr ;
            st.eolIsSignificant true ;
            to :=st.nextToken  ;
            ctr1 :=inoc  ;
            int[] qoh :=new int[ctr1];
            String[] ino :=new String[ctr1];
            String[] des :=new String[ctr1];
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if str  :=1 
                    Begin
                        st := str+1;
                        ino[k] :=st.sval;
                    end;
                    else if str  :=2 
                    Begin
                        str :=1;
                        des[k] :=st.sval;
                    end;
                end;
                if to  :=-2 
                Begin
                    if nu  :=1 
                    Begin
                        nu++;
                    end;
                    else if nu  :=2 
                    Begin
                        qoh[k] := int st.nval;
                        nu :=nu+1;
                    end;
                    else if nu  :=3 
                    Begin
                        nu :=1;
                        k :=k+1;
                    end;
                end;
                to :=st.nextToken  ;
            end;
            close fr;
        
        ctr :=1;nu :=1;str :=1;to :=0;k :=0;
        
            a :=true;
            ctr1 :=inoc  ;
            FileReader fr1 :=new FileReader "sell.dat" ;
            Object of class StreamTokenizer := st  fr1 ;
            st1.eolIsSignificant true ;
            to :=st1.nextToken  ;
            int[] qs :=new int[ctr1];
            String[] dat :=new String[ctr1];
            String[] ino1 :=new String[ctr1];
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if str  :=1 
                    Begin
                        dat[k] :=st1.sval;
                        str := str+1;
                    end;
                    else if str  :=2 
                    Begin
                        str :=1;
                        ino1[k] :=st1.sval;
                    end;
                end;
                if to  :=-2 
                Begin
                    qs[k] := int st1.nval;
                    k :=k+1;
                end;
                to :=st1.nextToken  ;
            end;
            close fr1;
        
        String[] mo :=Begin"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"end;;
        ctr :=1;nu :=1;str :=1;to :=0;k :=0;
        File f3 :=new File "reorder.dat" ;
        
            b :=true;
            ctr1 :=inoc  ;
            FileReader fr2 :=new FileReader "reorder.dat" ;
           Object of class StreamTokenizer := st  fr2 ;
            st2.eolIsSignificant true ;
            to :=st2.nextToken  ;
            String[] ino2 :=new String[ctr1];
            String[] gra :=new String[ctr1];
            String[] dat1 :=new String[ctr1];
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if str  :=2 
                    Begin
                        dat1[k] :=st2.sval;
                        str :=str+1;
                    end;
                    else if str  :=1 
                    Begin
                        str :=str+1;
                        ino2[k] :=st2.sval;
                    end;
                    else if str  :=3 
                    Begin
                        str :=1;
                        gra[k] :=st2.sval;
                        k :=k+1;
                    end;
                end;
                to :=st2.nextToken  ;
            end;
            close fr2;
        
        Displayln Integer.parseInt  dat1[1].substring 5,7   +" "+da ;
        var qs1,b : Integer;
        Displayln "INO\tDES\tQOH\tQS\tCLASS" ;
        
        for int i := 0 to length of ino  next i :=i+1, qs1 :=0, b :=0  do  
        Begin
            
            if da  :=-1 
            Begin
                for int j := 0 to length of ino1  next 1  do 
                Begin
                    if  dat[j].substring 0,3  .equalsIgnoreCase mo[m-1]  
                        if ino1[j].equalsIgnoreCase ino[i]  
                            qs1+ :=qs[j];
                end;
                    

                if qs1! :=0 
                Begin
                    Display ino[i]+"\t"+des[i]+"\t"+qoh[i]+"\t" ;
                    Display qs1+"\t" ;
                end;
                for  b <  length of ino2  next 1  do 
                Begin
                    if  dat1[b].substring 0,3  .equalsIgnoreCase mo[m-1]  
                        if ino[b].equalsIgnoreCase ino[i]  
                        Begin
                            if qs1! :=0 
                            Displayln gra[b] ;
                            break;
                        end;
                end;
                if b> :=ino2.length 
                    if qs1! :=0 
                        Displayln "Poor" ;
            end;
            else
            Begin
                for int j := 0 to length of ino1  next 1  do 
                Begin
                    if  dat[j].substring 0,3  .equalsIgnoreCase mo[m-1]  
                        if Integer.parseInt  dat[j].substring 5,7     :=da 
                            if ino1[j].equalsIgnoreCase ino[i]  
                                qs1+ :=qs[j];
                end;
                    

                if qs1! :=0 
                Begin
                    Display ino[i]+"\t"+des[i]+"\t"+qoh[i]+"\t" ;
                    Display qs1+"\t" ;
                end;
                for b< length of ino2  next 1  do for ;b<ino2.length;b++ 
                Begin
                    if  dat1[b].substring 0,3  .equalsIgnoreCase mo[m-1]  
                        if Integer.parseInt  dat1[b].substring 5,7     :=da 
                            if ino[b].equalsIgnoreCase ino[i]  
                            Begin
                            if qs1! :=0 
                                Displayln gra[b] ;
                                break;
                            end;
                end;
                if b> :=ino2.length 
                            if qs1! :=0 
                    Displayln "Poor" ;
            end;
            
        end;
    end;

    // deletes the ino which is recieved in parameter
    // ----------------------------------------------

    Non-Returning Parameterised method  delete  String in,String re  throws Exception 
    Begin
        var to : Integer;
        FileReader fr :=new FileReader "master.dat" ;
        Object of class StreamTokenizer := st  fr ;
        st.eolIsSignificant true ;

        Object of FileOutputStream  := fos "master2.dat",true ;
        Object of BufferedOutputStream  := bosfos ;
        Object of DataOutputStream  :=dos Stream bos ;
        
        Object of FileOutputStream := f "deleted.dat",true ;
        Object of BufferedOutputStream  := b f ;
        Object of DataOutputStream := d b ;
        
        while to! :=-1 
        Begin
            to :=st.nextToken  ;
            if to  :=-1 
                break;
            if in.equalsIgnoreCase st.sval  
            Begin
                Date da :=new Date  ;
                String s :=da.toString  ;
                s :=s.substring 4,7 +"00"+s.substring 8,10 +"00"+s.substring 24 ;
                d Write to File s.trim   ;
                d Write to File st.sval.trim   ;
                to :=st.nextToken  ;
                if to  :=-1 
                    break;
                if to  :=10 
                    to :=st.nextToken  ;
                d Write to File st.sval.trim   ;
                d Write to File re.trim   ;
                d Write to File "\n" ;
                to :=st.nextToken  ;
                to :=st.nextToken  ;
                while to! :=10 && to! :=-1 
                Begin
                    to :=st.nextToken  ;
                end;
            end;
            else
            Begin 
                Write to File  st.sval.trim   ;
                to :=st.nextToken  ;
                if to  :=-1 
                    break;
                if to  :=10 
                    to :=st.nextToken  ;
                Write to File  st.sval.trim   ;
                to :=st.nextToken  ;
                if to  :=-1 
                    break;
                if to  :=10 
                    to :=st.nextToken  ;
                Write to File  String.valueOf st.nval .trim   ;
                to :=st.nextToken  ;
                if to  :=10 
                    to :=st.nextToken  ;
                Write to File  String.valueOf st.nval .trim   ;
                to :=st.nextToken  ;
                if to  :=10 
                    to :=st.nextToken  ;
                Write to File  String.valueOf st.nval .trim   ;
                to :=st.nextToken  ;
                Write to File  "\n" ;
            end;
        end;

        close d  ;
        close b  ;
        close f  ;
        
        close dos  ;
        close bos  ;
        close fos  ;

        close fr  ;
        File f1 :=new File "master.dat" ;
        File f2 :=new File "master2.dat" ;
        f1.delete  ;
        f2.renameTo f1 ;
        f2.delete  ;

    end;
    Non Returning Parameterised method  rolc int m,int da  throws Exception 
    Begin
        var ctr,nu,st1,to,k : Integer;
        var c : character';
        File f1 :=new File "master.dat" ;
        if f1.exists   
        Begin
            Object of BufferedReader  :=br;
            Object of FileReader  := fr  "master.dat" ;
           Object of class StreamTokenizer := st fr ;
            st.eolIsSignificant true ;
            to :=st.nextToken  ;
            int[] roq :=new int[ctr1];
            int[] qoh :=new int[ctr1];
            int[] rol :=new int[ctr1];
            String[] ino :=new String[ctr1];
            String[] des :=new String[ctr1];
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if str  :=1 
                    Begin
                        str :=str+1;
                        ino[k] :=st.sval;
                    end;
                    else if str  :=2 
                    Begin
                        str :=1;
                        des[k] :=st.sval;
                    end;
                end;
                if to  :=-2 
                Begin
                    if nu  :=1 
                    Begin
                        roq[k] := int st.nval;
                        nu := nu+1;
                    end;
                    else if nu  :=2 
                    Begin
                        qoh[k] := int st.nval;
                        nu :=nu+1;
                    end;
                    else if nu  :=3 
                    Begin
                        rol[k] := int st.nval;
                        nu :=1;
                        k :=k+1;
                    end;
                end;
                to :=st.nextToken  ;
            end;
            close fr  ;

            for int i := 0 to ctr1  next 1  do
            Begin
                if qoh[i]<rol[i] 
                Begin
                    Display "The qoh for "+ino[i]+" is lesser than Rol, Do you want to reorder? " ;    
                    Input c :=br.readLine  .trim  .charAt 0 ;
                    if c  :='y' || c  :='Y' 
                        update ino[i],3,0 ;
                end;
            end;
        end;
    end;
    
    Non-Returning Parameterised method  sort int ctr1  throws Exception 
    Begin
        var ctr,nu,str,to,k : Integer;
        File f1 :=new File "master.dat" ;
        if f1.exists   
        Begin
            Object of FileReader  := fr "master.dat" ;
            Object of class StreamTokenizer := st fr ;
            st.eolIsSignificant true ;
            to :=st.nextToken  ;

            int[] roq :=new int[ctr1];
            int[] qoh :=new int[ctr1];
            int[] rol :=new int[ctr1];
            String[] ino :=new String[ctr1];
            String[] des :=new String[ctr1];
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if str  :=1 
                    Begin
                        str :=str+1;
                        ino[k] :=st.sval;
                    end;
                    else if str  :=2 
                    Begin
                        str :=1;
                        des[k] :=st.sval;
                    end;
                end;
                if to  :=-2 
                Begin
                    if nu  :=1 
                    Begin
                        roq[k] := int st.nval;
                        nu :=nu+1;
                    end;
                    else if nu  :=2 
                    Begin
                        qoh[k] := int st.nval;
                        nu :=nu+1;
                    end;
                    else if nu  :=3 
                    Begin
                        rol[k] := int st.nval;
                        nu :=1;
                        k :=k+1;
                    end;
                end;
                to :=st.nextToken  ;
            end;
            close fr  ;
            var t1: String;
            var t2 : Integer;
            
            for int i := 0 to ctr1  next 1  do 
                for int j := 0 to ctr1-1  next 1  do
                Begin
                    if ino[j].compareTo ino[j+1] >0 
                    Begin
                        t1 :=ino[j+1];
                        ino[j+1] :=ino[j];
                        ino[j] :=t1;

                        t1 :=des[j+1];
                        des[j+1] :=des[j];
                        des[j] :=t1;

                        t2 :=roq[j+1];
                        roq[j+1] :=roq[j];
                        roq[j] :=t2;

                        t2 :=qoh[j+1];
                        qoh[j+1] :=qoh[j];
                        qoh[j] :=t2;

                        t2 :=rol[j+1];
                        rol[j+1] :=rol[j];
                        rol[j] :=t2;
                    end;
                end;
            Object of FileOutputStream  := fos "master2.dat",true ;
            Object of BufferedOutputStream := bos fos ;
            Object of DataOutputStream  :=dos bos ;
            for int i := 0 to ctr1  next 1  do 
            Begin
                Write to File  ino[i] ;
                Write to File  des[i] ;
                Write to File  String.valueOf roq[i]  ;
                Write to File  String.valueOf qoh[i]  ;
                Write to File  String.valueOf rol[i]  ;
                Write to File  "\n" ;
            end;
            close dos  ;
            close bos  ;
            close fos  ;

            File f2 :=new File "master2.dat" ;
            f1.delete  ;
            f2.renameTo f1 ;
            f2.delete  ;

        end;
    end;

    // counts the no. of records
    // -------------------------

    Returning non Parameterised method inoc  throws Exception of type integer
    Begin
        var ctr,ctr1,to : Integer;
        var s1 : String;
        if a 
            s1 :="sell.dat";
        else if b 
            s1 :="reorder.dat";
        else
            s1 :="master.dat";
        File f :=new File s1 ;
        if f.exists   
        Begin
            Onject of FileReader  := fr s1 ;
            Object of class StreamTokenizer := st  fr ;
            st.eolIsSignificant true ;
            while to! :=-1 
            Begin
                to :=st.nextToken  ;
                if to  :=-1 
                    break;
                if to  :=-3 
                Begin
                    if ctr  :=1 
                    Begin
                        ctr1++;
                        ctr :=ctr+1;
                    end;           
                    else if ctr  :=2 
                    Begin
                        if !b 
                            ctr :=1;
                        else
                            ctr :=ctr+1;
                    end;
                    else if ctr  :=3 
                        ctr :=1;
                end;
            end;           
            close fr  ;
        end;
        a :=false;
        b :=false;
        return ctr1;
    end;


    Non-Returning Parameterised method  update String in,int t,int ch  throws Exception 
    Begin
        var to,ro,ctr1,ctr2,k : Integer;
        
        varf :boolean ;

        File f1 :=new File "master.dat" ;
        if f1.exists   
        Begin
        Object of FileReader := fr "master.dat" ;
        Object of class StreamTokenizer := st fr ;
        st.eolIsSignificant true ;

            Object of FileOutputStream  := fos "master2.dat",true ;
            Object of BufferedOutputStream := bos fos ;
            Object of DataOutputStream  :=dos bos ;
        while to! :=-1 
        Begin
            if to  :=-3 
            Begin
                if ctr1  :=1 
                Begin
                    Write to File  st.sval.trim   ;
                    ctr1++;
                    if in.equalsIgnoreCase st.sval  
                    Begin
                        f :=true;
                        in :=st.sval;
                    end;
                end;
                else if ctr1  :=2 
                Begin
                    Write to File  st.sval.trim   ;
                    ctr1 :=1;
                end;
            end;
            if to  :=-2 
            Begin
                if ctr2  :=1 
                Begin
                    if f 
                    Begin
                        ro := int st.nval;
                        if t  :=2 
                            Write to File  String.valueOf ch .trim   ;
                        else
                            Write to File  String.valueOf st.nval .trim   ;
                    end;
                    else
                        Write to File  String.valueOf st.nval .trim   ;
                    ctr2++;
                end;
                else if ctr2  :=2 
                Begin
                    ctr2++;
                    if f 
                    Begin
                        if t  :=3 
                        Begin
                            Write to File  String.valueOf  st.nval+ro  .trim   ;
                        end;
                        else if t  :=4 
                        Begin
                            Write to File  String.valueOf  st.nval-ch  .trim   ;
                            Displayln  st.nval-ch  ;
                        end;
                        else
                            Write to File  String.valueOf st.nval .trim   ;
                    end;
                    else
                        Write to File  String.valueOf st.nval .trim   ;
                            
                end;

                else if ctr2  :=3 
                Begin
                    ctr2 :=1;
                    if f 
                    Begin
                        if t  :=1 
                        Begin
                            Write to File  String.valueOf ch .trim   ;
                        end;
                        else
                            Write to File  String.valueOf st.nval .trim   ;
                    end;
                    else
                        Write to File  String.valueOf st.nval .trim   ;
                end;
            end;
            if to  :=10 
            Begin
                if f 
                    f :=false;
                Write to File  "\n" ;
            end;
            to :=st.nextToken  ;
        end;

          close dos  ;
          close bos  ;
          close fos  ;

          close fr  ;
        File f2 :=new File "master2.dat" ;
        f1.delete  ;
        f2.renameTo f1 ;
        f2.delete  ;
        if t  :=3 
        Begin
        Object of FileOutputStream  := fo "reorder2.dat",true ;
        Object of BufferedOutputStream  := bo fo ;
        Object of DataOutputStream  := d bo ;
        var s : String;
        var t3 : integer;
        File f3 :=new File "reorder.dat" ;
        if f3.exists   
        Begin
            var ctr : Integer;
            var z,x : boolean;
            Object of FileReader  := fr1 "reorder.dat" ;
            Object of class StreamTokenizer := st; fr1 ;
            st1.eolIsSignificant true ;
            to :=st1.nextToken  ;
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if ctr  :=1 
                    Begin
                        ctr++;
                        d Write to File st1.sval.trim   ;
                        if in.equalsIgnoreCase st1.sval  
                        Begin
                            z :=true;
                            x :=true;
                        end;
                    end;
                    else if ctr  :=2 
                    Begin
                        if z 
                        Begin
                            Date d1 :=new Date  ;
                            s :=d1.toString  ;
                            s :=s.substring 4,7 +"00"+s.substring 8,10 +"00"+s.substring 24 ;
                            d Write to File s.trim   ;
                        end;
                        else
                            d Write to File st1.sval.trim   ;  
                        ctr++;
                    end;
                    else if ctr  :=3 
                    Begin
                        ctr :=1;
                        
                        if t3>2 
                            d Write to File "Excellent" ;
                        else if t3>1 
                            d Write to File "Good" ;
                        else if t3>0 
                            d Write to File "Average" ;
                        else
                            d Write to File "Poor" ;
                    end;
                end;
                if to  :=-2 
                Begin
                    if z 
                    Begin
                        d Write to File String.valueOf  t3 := int  st1.nval+1    ;
                    end;
                    else
                    Begin
                        d Write to File String.valueOf t3 := int st1.nval  ;
                    end;
                end;
                if to  :=10 
                Begin
                    d Write to File "\n" ;
                    if ctr  :=1 
                        z :=false;
                end;
                to :=st1.nextToken  ;
            end;
            if !x 
            Begin
                Date d3 :=new Date  ;
                s :=d3.toString  ;
                s :=s.substring 4,7 +"00"+s.substring 8,10 +"00"+s.substring 24 ;
                d Write to File in.trim   ;
                d Write to File s.trim   ;
                d Write to File String.valueOf  t3 := rotc in +1   .trim   ;
                if t3>2 
                    d Write to File "Excellent" ;
                else if t3>1 
                    d Write to File "Good" ;
                else if t3>0 
                    d Write to File "Average" ;
                else
                    d Write to File "Poor" ;
                d Write to File "\n" ;
            end;
            close fr1  ;
        end;
        else
        Begin
            Date d2 :=new Date  ;
            s :=d2.toString  ;
            s :=s.substring 4,7 +"00"+s.substring 8,10 +"00"+s.substring 24 ;
            d Write to File in.trim   ;
            d Write to File s.trim   ;
            d Write to File String.valueOf  t3 := rotc in +1   .trim   ;
            if t3>2 
                d Write to File "Excellent" ;
            else if t3>1 
                d Write to File "Good" ;
            else if t3>0 
                d Write to File "Average" ;
            else
                d Write to File "Poor" ;
            d Write to File "\n" ;
        end;
        close d  ;
        close bo  ;
        close fo  ;
        File f4 :=new File "reorder2.dat" ;
        f3.delete  ;
        f4.renameTo f3 ;
        f4.delete  ;
        end;
        end;
    end;

    Returning Parameterised method  rotc String in throws Exception of type Integer
    Begin
        File f1 :=new File "reorder.dat" ;
        var k: Integer;
        if f1.exists   
        Begin
            Object of FileReader  :=fr "reorder.dat" ;
            Object of class StreamTokenizer := st; fr ;
            st.eolIsSignificant true ;
            int to :=st.nextToken  ;
            var ctr : Integer;
            varf : boolean ;
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if ctr  :=2 
                        ctr++;
                    else if ctr  :=1 
                    Begin
                        if in.equalsIgnoreCase st.sval  
                            f :=true;
                        ctr++;
                    end;
                    else if ctr  :=3 
                        ctr :=1;
                end;
                if to  :=-2 
                    if f 
                        k := int st.nval;
                to :=st.nextToken  ;
            end;

            close fr  ;
        end;
        return k;
    end;
    //
    //check weather the input quantity qs  of item no. in  is less than t :=1 ->qoh t :=2 ->rol
    //-------------------------------------------------------------------------------------

    Returning Parameterised method  boolean qcheck String in,int qs,int t  throws Exception of type Boolean 
    Begin
        var to: Integer;
        var v,f : boolean;
        Object of File f1 :=new File "master.dat" ;
        if f1.exists   
        Begin
            Object of FileReader  := fr "master.dat" ;
            Object of class StreamTokenizer := st; fr ;
            st.eolIsSignificant true ;
            int ctr1 :=1,ctr2 :=1;
            //redo
            to :=st.nextToken  ;
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if ctr1  :=1 
                    Begin
                        ctr1++;
                        if in.equalsIgnoreCase st.sval  
                            f :=true;
                    end;
                    else if ctr1  :=2 
                    Begin
                        ctr1 :=1;
                    end;
                end;
                if to  :=-2 
                Begin
                    if ctr2  :=1 
                    Begin
                        ctr2++;
                    end;
                    else if ctr2  :=2 
                    Begin
                        ctr2++;
                        if f 
                            if t  :=1 
                            Begin
                                if qs< :=st.nval 
                                    v :=true;
                            end;
                            else if t  :=2 
                            Begin
                                qs := int st.nval;
                            end;
                    end;
                    else if ctr2  :=3 
                    Begin
                        ctr2 :=1;
                        if f 
                            if t  :=2 
                                if qs< :=st.nval 
                                Begin
                                    v :=true;
                                end;
                    end;
                end;
                if to  :=10 
                    if f 
                        f :=false;
                to :=st.nextToken  ;
            end;
            fr.close  ;
        end;
        return v;
    end;
    Non-Returning non Parameterised method  sell   throws Exception
    Begin
        Object of BufferedReader := br;
        var v:boolean ;
        File f :=new File "master.dat" ;
        if f.exists   
        Begin
            Object of FileReader  := fr "master.dat" ;
            Object of class StreamTokenizer := st; fr ;
            st.eolIsSignificant true ;
            var in: String ;
            var to,qs : Integer;
            for ;; 
            Begin
                for ;; 
                Begin
                    v :=true;
                    Display "Enter Item Number eg. I001 : " ;
                    Input in :=br.readLine  .trim  ;
              
                    if in.length  ! :=4 
                    Begin
                      v :=false;
                      continue;
                    end;       
                    if in.charAt 0 ! :='I' && in.charAt 0 ! :='i' 
                        v :=false;
                    for int i := 1 to 4  next 1  do 
                    Begin
                        if ! in.charAt i > :='0' && in.charAt i < :='9'  
                            v :=false;
                    end;
                    v := validate in  && v ;
                    if !v 
                    Begin
                        Displayln "Invalid Item Number!" ;
                    end;
                    if v 
                        break;
                end;
                v :=false;
                for ;; 
                Begin
                    Display "Enter the Quatity Sold: " ;
                    Input qs :=Integer.parseInt br.readLine  .trim   ;
                    v :=qcheck in,qs,1 ; 
                    if !v 
                    Begin
                        Displayln "Insufficient quantity on hand!" ;
                        continue;
                    end;
                    break;
                end;
                Date d :=new Date  ;
                String s :=d.toString  ;
                s :=s.substring 4,7 +"00"+s.substring 8,10 +"00"+s.substring 24 ;
                Object of FileOutputStream  := fos := "sell.dat",true ;
                Object of BufferedOutputStream  :=bos fos ;
                Object of DataOutputStream  :=dos bos ;
                Write to File  s.trim   ;
                Write to File  in.trim   ;
                Write to File  String.valueOf qs .trim   ;
                Write to File  "\n" ;
                
                close dos  ;
                close bos  ;
                close fos  ;
                break;
            end;
            close fr  ;
            update in,4,qs ;

        end;
    end;
end;

    var qoh,rol,roq : Integer;
    var a,b: boolean;
   
    non returning method "menu  throws Exception"
    Begin
        //premenu  ;
        var ch,ch1,ch4,ne : Integer;
        var c: character;
        var in,re : String;
        var v,v1 : boolean ;
        
        object of BufferedReader  := br;
        for ;; 
        Begin
        Displayln "Select any one of the following options: " ;
        Displayln "1.Modify Records" ;
        Displayln "2.Sell Products" ;
        Displayln "3.Veiw Records" ;
        Displayln "4.Search for Records" ;
        Displayln "5.Exit" ;
        
        while ch<1 || ch>5   do
        Begin
            Display "Enter your choice: " ;
            Input ch  := Integer.parseInt br.readLine  .trim   ;

        end;
        
        for int i := 1 to 40  next 1  do
            Displayln  ;
        if ch  :=1 
        Begin
            Displayln "Select any one of the following options: " ;
            Displayln "1.Add Records" ;
            Displayln "2.Delete Records" ;
            Displayln "3.Change Re-Order Quantity" ;
            Displayln "4.Change Re-Order Level" ;
            Displayln "5.Check Quantity On Hand with Re-Order Level" ;
            
            while ch1<1 || ch1>5   do
            Begin
                Display "Enter your choice: " ;
                Input ch1 :=Integer.parseInt br.readLine  .trim   ;
            end;
            
            for int i := 1 to 40  next 1  do
                Displayln  ;
            if ch1  :=1 
            Begin
                for ;; 
                Begin
                    input  ;
                    write  ;
                    sort inoc   ;
                    Display "Do you have more records to enter: " ;
                    Input c :=br.readLine  .trim  .charAt 0 ;
                    if c  :='n' || c  :='N' 
                        break;
                end;
                sort inoc   ;
            end;
            if ch1  :=2 
            Begin
                for ;; 
                Begin
                    Display "Enter the item number you want to delete: " ;
                    Input in :=br.readLine  .trim  ;
                    v1 :=validate in ;
                    if v1 
                    Begin
                        for ;; 
                        Begin
                            v :=true;
                            Display "Enter the reason for deletion: " ;
                            Input re :=br.readLine  .trim  ;
                            if re.length  >15 
                                v :=false;
                            for int i := 0 to length of re  next 1  do
                            Begin       
                                c :=re.charAt i ;
                                if !  c> :='A' && c< :='Z'  ||  c  :=' '  ||  c> :='a' && c< :='z'  ||  c>'0' && c< :='9'   
                                    v :=false;
                            end;
                            if v 
                                break;
                        end;
                        re :=spaces re," " .trim  ;
                        re :=re.substring 0,re.length  -2 ;
                        delete in,re ;
                        break;
                    end;
                    else
                        Displayln "Invalid Item Number!" ;
                end;
            end;
            if ch1  :=3 
            Begin
                for ;; 
                Begin
                    Display "Enter the item number for changing ROQ: " ;
                    Input in :=br.readLine  .trim  ;
                    v1 :=validate in ;
                    if v1 
                        break;
                    else
                        Displayln "Invalid Item Number!" ;
                end;
                do
                Begin
                    Display "Enter the new ROQ: " ;
                    Input ne :=Integer.parseInt br.readLine  .trim   ;
                end;while ne<2 ;
                update in,2,ne ;
            end;
            if ch1  :=4 
            Begin
                for ;; 
                Begin
                    Display "Enter the item number for changing ROL: " ;
                    Input in :=br.readLine  .trim  ;
                    v1 :=validate in ;
                    if v1 
                        break;
                    else
                        Displayln "Invalid Item Number!" ;
                end;
                while ne<2   do
                Begin
                    Display "Enter the new ROL: " ;
                    Input ne :=Integer.parseInt br.readLine  .trim   ;
                end;
                update in,1,ne ;
            end;
            if ch1  :=5 
            Begin
                rolc inoc   ;
            end;
        end;
        if ch  :=2 
        Begin
            File f1 :=new File "master.dat" ;
            if f1.exists   
            Begin
                sell  ;
                sort inoc   ;
            end;
        end;
        if ch  :=4 
        Begin
            File f1 :=new File "master.dat" ;
            if f1.exists   
            Begin
                    Display "Enter the item number for searching: " ;
                    Input in :=br.readLine  .trim  ;
                    v1 :=validate in ;
                    if v1 
                        Displayln "Record Found!" ;
                    else
                        Displayln "Record Not Found!" ;
            end;
        end;
        if ch  :=3 
        Begin
            Displayln "Select any one of the following options: " ;

            Displayln "1.Master File" ;
            Displayln "2.Sales File" ;
            Displayln "3.Reorder File" ;
            Displayln "4.Deletion File" ;

            while ch4<1 || ch4>4   do
            Begin
                Display "Enter your choice: " ;
                Input ch4 :=Integer.parseInt br.readLine  .trim   ;
            end;
            
            for int i := 1 to 40  next 1  do
                Displayln  ;
            read ch4 ;
        end;
        if ch  :=5 
            System.exit 0 ;
        end;
    end;

    // accepts data from user and stores it in properties
    // --------------------------------------------------

    Non returning method input  throws Exception
    Begin
        Object of class BufferedReader  := br;
        var v :boolean;
        var ctr1: Integer;
        var c : Character;
        for ;; 
        Begin
            v :=true;
            ctr1 :=0;
            Display "Enter Item Number eg. I001 : " ;
            Input ino :=br.readLine  .trim  .toUpperCase  ;
            if ino.length  ! :=4 
            Begin
                v :=false;
                continue;
            end;
            if ino.charAt 0 ! :='I' && ino.charAt 0 ! :='i' 
                v :=false;
            for int i := 1 to 4  next 1  do
            Begin
                if ! ino.charAt i > :='0' && ino.charAt i < :='9'  
                    v :=false;
            end;
            if ! validate ino   && v 
                break;
        end;
        for ;; 
        Begin
            v :=true;
            ctr1 :=0;
            Display "Enter the Description: " ;
            Input des :=br.readLine  .trim  ;
            if des.length  >15 
                v :=false;
            for int i := 0 to length of des  next 1  do
            Begin
                c :=des.charAt i ;
                if !  c> :='A' && c< :='Z'  ||  c> :='a' && c< :='z'  ||  c  :=' '  ||  c>'0' && c< :='9'   
                    v :=false;
                if c> :='0' && c< :='9' 
                    ctr1 :=ctr1+1;
            end;
            if ctr1  :=des.length   
            Begin
                v :=false;
            end;
            if v 
                break;
        end;
        des :=spaces des," " .trim  ;
        des :=des.substring 0,des.length  -2 ;
        var t1: String;
        ctr1 :=0;
        while qoh<0   do
        Begin
            Display "Enter Quantity on Hand: " ;
            Input t1 :=br.readLine  .trim  ;
            
            qoh :=Integer.parseInt t1 ;
        end;
        
        ctr1 :=0;
        
        while rol<2   do
        Begin
            Display "Enter Re-order level: " ;
            Input t1 :=br.readLine  .trim  ;
            ctr1 :=0;
            for int i := 0 to length of t1  next 1  do
            Begin
                c :=t1.charAt i ;
                if c> :='0' && c< :='9' 
                    ctr1 :=ctr1+1;
            end;
            if ! ctr1  :=t1.length    
            Begin
                continue;
            end;
            rol :=Integer.parseInt t1 ;
        end;
        
        ctr1 :=0;
        while roq<2   do
        Begin
            Display "Enter Re-order quantity: " ;
            Input t1 :=br.readLine  .trim  ;
            ctr1 :=0;
            for int i := 0 to length of t1  next 1  do 
            Begin
                c :=t1.charAt i ;
                if c> :='0' && c< :='9' 
                    ctr1 := ctr1+1;
            end;
            if ! ctr1  :=t1.length    
            Begin
                continue;
            end;
            roq :=Integer.parseInt t1 ;
        end;
    end;

    // checks weather or not the item numer exists in master file or not
    //------------------------------------------------------------------

    Non returning parameterised method validate String in throws Exception of type boolean
    Begin
        var v :boolean;
        var to,ctr : Integer;
        File f :=new File "master.dat" ;
        if f.exists   
        Begin
            FileReader fr :=new FileReader "master.dat" ;
            Object of class StreamTokenizer := st;
            st.eolIsSignificant true ;
            while to! :=-1 
            Begin
                to :=st.nextToken  ;
                if in.equalsIgnoreCase st.sval  
                    v :=true;
                to :=st.nextToken  ;
                to :=st.nextToken  ;
                to :=st.nextToken  ;
                while to! :=10 && to! :=-1 
                Begin
                    to :=st.nextToken  ;
                end;
            end;
            fr.close  ;
        end;
        else
            v :=false;
        return v;
    end;

    // reads the file and prints the records
    // -------------------------------------

    Non returning parameterised method  read int x throws Exception
    Begin
        var s : String;
        if x  :=1 
            s :="master.dat";
        if x  :=2 
            s :="sell.dat";
        if x  :=3 
            s :="reorder.dat";
        if x  :=4 
            s :="deleted.dat";
        File f :=new File s ;
        if  f.exists    
        Begin
            var to : Integer;
            String[] ou;
            FileReader fr :=new FileReader s ;
            Object of class StreamTokenizer := st;
            st.eolIsSignificant true ;
            if x  :=1 
            Begin
                Displayln "ino\tdes\troq\tqoh\trol" ;
            end;
            if x  :=4 
            Begin
                Displayln "dat\tino\tdes\tres" ;
            end;

                while to! :=-1 
                Begin
                    if to  :=-3 
                    Begin
                        if x  :=1 || x  :=3 
                            if ctr  :=1 
                                Display st.sval+"\t" ;
                            else
                            Begin
                                ou :=st.sval.split "00" ;
                                for int i := 0 to length of ou  next 1  do 
                                    Display ou[i]+" " ;
                                Display "\t" ;
                            end;
                        else
                            if ctr  :=2 
                                Display st.sval+"\t" ;
                            else
                            Begin
                                ou :=st.sval.split "00" ;
                                for int i := 0 to length of ou  next 1  do 
                                    Display ou[i]+" " ;
                                Display "\t" ;
                            end;
                        ctr :=ctr+1;
                    end;
                    if to  :=-2 
                    Begin
                        Display  int st.nval+"\t" ;
                        ctr := ctr+1;
                    end;
                    if to  :=10 
                    Begin
                        ctr := ctr+1;
                        if x  :=1 
                            if ctr  :=7 
                            Begin
                                Displayln  ;
                                ctr :=1;
                            end;
                            else
                                ctr := ctr-1;
                        if x  :=2 
                            if ctr  :=5 
                            Begin
                                Displayln  ;
                                ctr :=1;
                            end;
                            else
                                ctr := ctr-1;
                        if x  :=3 
                            if ctr  :=6 
                            Begin
                                Displayln  ;
                                ctr :=1;
                            end;
                            else
                                ctr := ctr-1;
                        if x  :=4 
                            if ctr  :=6 
                            Begin
                                Displayln  ;
                                ctr :=1;
                            end;
                            else
                                ctr := ctr-1;
                    end;
                    to :=st.nextToken  ;
                end;
            fr.close  ;
        end;   
    end;

    // writes the properties into master file
    // --------------------------------------

    Non-returning method write  throws Exception
    Begin
        Object of FileOutputStream  := fos"master.dat",true ;
        Object of BufferedOutputStream := bos fos ;
        Object of DataOutputStream  := dos bos ;
        Write to File  ino ;
        Write to File  des ;
        Write to File  String.valueOf roq  ;
        Write to File  String.valueOf qoh  ;
        Write to File  String.valueOf rol  ;
        Write to File  "\n" ;

        close dos  ;
        close bos  ;
        close fos  ;
    end;

    // change spaces to 00 using string tokenizer
    //-------------------------------------------

    Returning-Parameterised method spaces String d,String c  of type String 
    Begin
        var t :String;
        Object of class StreamTokenizer := st  d,c,true ;
        while st.hasMoreTokens     
        Begin
            if c.equals " "  
                t+ :=st.nextToken  +"00";
            if c.equals "00"  
                t+ :=st.nextToken  +" ";
        end;
        //Displayln d+"\n"+t ;
        return t;
    end;


    Non-Returning Parameterised method  repor int m,int da  throws Exception
    Begin
        var ctr1 : Integer;
        var ctr,nu,str,to,k : Integer;

            FileReader fr :=new FileReader "master.dat" ;
           Object of class StreamTokenizer := st  fr ;
            st.eolIsSignificant true ;
            to :=st.nextToken  ;
            ctr1 :=inoc  ;
            int[] qoh :=new int[ctr1];
            String[] ino :=new String[ctr1];
            String[] des :=new String[ctr1];
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if str  :=1 
                    Begin
                        st := str+1;
                        ino[k] :=st.sval;
                    end;
                    else if str  :=2 
                    Begin
                        str :=1;
                        des[k] :=st.sval;
                    end;
                end;
                if to  :=-2 
                Begin
                    if nu  :=1 
                    Begin
                        nu++;
                    end;
                    else if nu  :=2 
                    Begin
                        qoh[k] := int st.nval;
                        nu :=nu+1;
                    end;
                    else if nu  :=3 
                    Begin
                        nu :=1;
                        k :=k+1;
                    end;
                end;
                to :=st.nextToken  ;
            end;
            close fr;
        
        ctr :=1;nu :=1;str :=1;to :=0;k :=0;
        
            a :=true;
            ctr1 :=inoc  ;
            FileReader fr1 :=new FileReader "sell.dat" ;
            Object of class StreamTokenizer := st  fr1 ;
            st1.eolIsSignificant true ;
            to :=st1.nextToken  ;
            int[] qs :=new int[ctr1];
            String[] dat :=new String[ctr1];
            String[] ino1 :=new String[ctr1];
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if str  :=1 
                    Begin
                        dat[k] :=st1.sval;
                        str := str+1;
                    end;
                    else if str  :=2 
                    Begin
                        str :=1;
                        ino1[k] :=st1.sval;
                    end;
                end;
                if to  :=-2 
                Begin
                    qs[k] := int st1.nval;
                    k :=k+1;
                end;
                to :=st1.nextToken  ;
            end;
            close fr1;
        
        String[] mo :=Begin"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"end;;
        ctr :=1;nu :=1;str :=1;to :=0;k :=0;
        File f3 :=new File "reorder.dat" ;
        
            b :=true;
            ctr1 :=inoc  ;
            FileReader fr2 :=new FileReader "reorder.dat" ;
           Object of class StreamTokenizer := st  fr2 ;
            st2.eolIsSignificant true ;
            to :=st2.nextToken  ;
            String[] ino2 :=new String[ctr1];
            String[] gra :=new String[ctr1];
            String[] dat1 :=new String[ctr1];
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if str  :=2 
                    Begin
                        dat1[k] :=st2.sval;
                        str :=str+1;
                    end;
                    else if str  :=1 
                    Begin
                        str :=str+1;
                        ino2[k] :=st2.sval;
                    end;
                    else if str  :=3 
                    Begin
                        str :=1;
                        gra[k] :=st2.sval;
                        k :=k+1;
                    end;
                end;
                to :=st2.nextToken  ;
            end;
            close fr2;
        
        Displayln Integer.parseInt  dat1[1].substring 5,7   +" "+da ;
        var qs1,b : Integer;
        Displayln "INO\tDES\tQOH\tQS\tCLASS" ;
        
        for int i := 0 to length of ino  next i :=i+1, qs1 :=0, b :=0  do  
        Begin
            
            if da  :=-1 
            Begin
                for int j := 0 to length of ino1  next 1  do 
                Begin
                    if  dat[j].substring 0,3  .equalsIgnoreCase mo[m-1]  
                        if ino1[j].equalsIgnoreCase ino[i]  
                            qs1+ :=qs[j];
                end;
                    

                if qs1! :=0 
                Begin
                    Display ino[i]+"\t"+des[i]+"\t"+qoh[i]+"\t" ;
                    Display qs1+"\t" ;
                end;
                for  b <  length of ino2  next 1  do 
                Begin
                    if  dat1[b].substring 0,3  .equalsIgnoreCase mo[m-1]  
                        if ino[b].equalsIgnoreCase ino[i]  
                        Begin
                            if qs1! :=0 
                            Displayln gra[b] ;
                            break;
                        end;
                end;
                if b> :=ino2.length 
                    if qs1! :=0 
                        Displayln "Poor" ;
            end;
            else
            Begin
                for int j := 0 to length of ino1  next 1  do 
                Begin
                    if  dat[j].substring 0,3  .equalsIgnoreCase mo[m-1]  
                        if Integer.parseInt  dat[j].substring 5,7     :=da 
                            if ino1[j].equalsIgnoreCase ino[i]  
                                qs1+ :=qs[j];
                end;
                    

                if qs1! :=0 
                Begin
                    Display ino[i]+"\t"+des[i]+"\t"+qoh[i]+"\t" ;
                    Display qs1+"\t" ;
                end;
                for b< length of ino2  next 1  do for ;b<ino2.length;b++ 
                Begin
                    if  dat1[b].substring 0,3  .equalsIgnoreCase mo[m-1]  
                        if Integer.parseInt  dat1[b].substring 5,7     :=da 
                            if ino[b].equalsIgnoreCase ino[i]  
                            Begin
                            if qs1! :=0 
                                Displayln gra[b] ;
                                break;
                            end;
                end;
                if b> :=ino2.length 
                            if qs1! :=0 
                    Displayln "Poor" ;
            end;
            
        end;
    end;

    // deletes the ino which is recieved in parameter
    // ----------------------------------------------

    Non-Returning Parameterised method  delete  String in,String re  throws Exception 
    Begin
        var to : Integer;
        FileReader fr :=new FileReader "master.dat" ;
        Object of class StreamTokenizer := st  fr ;
        st.eolIsSignificant true ;

        Object of FileOutputStream  := fos "master2.dat",true ;
        Object of BufferedOutputStream  := bosfos ;
        Object of DataOutputStream  :=dos Stream bos ;
        
        Object of FileOutputStream := f "deleted.dat",true ;
        Object of BufferedOutputStream  := b f ;
        Object of DataOutputStream := d b ;
        
        while to! :=-1 
        Begin
            to :=st.nextToken  ;
            if to  :=-1 
                break;
            if in.equalsIgnoreCase st.sval  
            Begin
                Date da :=new Date  ;
                String s :=da.toString  ;
                s :=s.substring 4,7 +"00"+s.substring 8,10 +"00"+s.substring 24 ;
                d Write to File s.trim   ;
                d Write to File st.sval.trim   ;
                to :=st.nextToken  ;
                if to  :=-1 
                    break;
                if to  :=10 
                    to :=st.nextToken  ;
                d Write to File st.sval.trim   ;
                d Write to File re.trim   ;
                d Write to File "\n" ;
                to :=st.nextToken  ;
                to :=st.nextToken  ;
                while to! :=10 && to! :=-1 
                Begin
                    to :=st.nextToken  ;
                end;
            end;
            else
            Begin 
                Write to File  st.sval.trim   ;
                to :=st.nextToken  ;
                if to  :=-1 
                    break;
                if to  :=10 
                    to :=st.nextToken  ;
                Write to File  st.sval.trim   ;
                to :=st.nextToken  ;
                if to  :=-1 
                    break;
                if to  :=10 
                    to :=st.nextToken  ;
                Write to File  String.valueOf st.nval .trim   ;
                to :=st.nextToken  ;
                if to  :=10 
                    to :=st.nextToken  ;
                Write to File  String.valueOf st.nval .trim   ;
                to :=st.nextToken  ;
                if to  :=10 
                    to :=st.nextToken  ;
                Write to File  String.valueOf st.nval .trim   ;
                to :=st.nextToken  ;
                Write to File  "\n" ;
            end;
        end;

        close d  ;
        close b  ;
        close f  ;
        
        close dos  ;
        close bos  ;
        close fos  ;

        close fr  ;
        File f1 :=new File "master.dat" ;
        File f2 :=new File "master2.dat" ;
        f1.delete  ;
        f2.renameTo f1 ;
        f2.delete  ;

    end;
    Non Returning Parameterised method  rolc int m,int da  throws Exception 
    Begin
        var ctr,nu,st1,to,k : Integer;
        var c : character';
        File f1 :=new File "master.dat" ;
        if f1.exists   
        Begin
            Object of BufferedReader  :=br;
            Object of FileReader  := fr  "master.dat" ;
           Object of class StreamTokenizer := st fr ;
            st.eolIsSignificant true ;
            to :=st.nextToken  ;
            int[] roq :=new int[ctr1];
            int[] qoh :=new int[ctr1];
            int[] rol :=new int[ctr1];
            String[] ino :=new String[ctr1];
            String[] des :=new String[ctr1];
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if str  :=1 
                    Begin
                        str :=str+1;
                        ino[k] :=st.sval;
                    end;
                    else if str  :=2 
                    Begin
                        str :=1;
                        des[k] :=st.sval;
                    end;
                end;
                if to  :=-2 
                Begin
                    if nu  :=1 
                    Begin
                        roq[k] := int st.nval;
                        nu := nu+1;
                    end;
                    else if nu  :=2 
                    Begin
                        qoh[k] := int st.nval;
                        nu :=nu+1;
                    end;
                    else if nu  :=3 
                    Begin
                        rol[k] := int st.nval;
                        nu :=1;
                        k :=k+1;
                    end;
                end;
                to :=st.nextToken  ;
            end;
            close fr  ;

            for int i := 0 to ctr1  next 1  do
            Begin
                if qoh[i]<rol[i] 
                Begin
                    Display "The qoh for "+ino[i]+" is lesser than Rol, Do you want to reorder? " ;    
                    Input c :=br.readLine  .trim  .charAt 0 ;
                    if c  :='y' || c  :='Y' 
                        update ino[i],3,0 ;
                end;
            end;
        end;
    end;
    
    Non-Returning Parameterised method  sort int ctr1  throws Exception 
    Begin
        var ctr,nu,str,to,k : Integer;
        File f1 :=new File "master.dat" ;
        if f1.exists   
        Begin
            Object of FileReader  := fr "master.dat" ;
            Object of class StreamTokenizer := st fr ;
            st.eolIsSignificant true ;
            to :=st.nextToken  ;

            int[] roq :=new int[ctr1];
            int[] qoh :=new int[ctr1];
            int[] rol :=new int[ctr1];
            String[] ino :=new String[ctr1];
            String[] des :=new String[ctr1];
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if str  :=1 
                    Begin
                        str :=str+1;
                        ino[k] :=st.sval;
                    end;
                    else if str  :=2 
                    Begin
                        str :=1;
                        des[k] :=st.sval;
                    end;
                end;
                if to  :=-2 
                Begin
                    if nu  :=1 
                    Begin
                        roq[k] := int st.nval;
                        nu :=nu+1;
                    end;
                    else if nu  :=2 
                    Begin
                        qoh[k] := int st.nval;
                        nu :=nu+1;
                    end;
                    else if nu  :=3 
                    Begin
                        rol[k] := int st.nval;
                        nu :=1;
                        k :=k+1;
                    end;
                end;
                to :=st.nextToken  ;
            end;
            close fr  ;
            var t1: String;
            var t2 : Integer;
            
            for int i := 0 to ctr1  next 1  do 
                for int j := 0 to ctr1-1  next 1  do
                Begin
                    if ino[j].compareTo ino[j+1] >0 
                    Begin
                        t1 :=ino[j+1];
                        ino[j+1] :=ino[j];
                        ino[j] :=t1;

                        t1 :=des[j+1];
                        des[j+1] :=des[j];
                        des[j] :=t1;

                        t2 :=roq[j+1];
                        roq[j+1] :=roq[j];
                        roq[j] :=t2;

                        t2 :=qoh[j+1];
                        qoh[j+1] :=qoh[j];
                        qoh[j] :=t2;

                        t2 :=rol[j+1];
                        rol[j+1] :=rol[j];
                        rol[j] :=t2;
                    end;
                end;
            Object of FileOutputStream  := fos "master2.dat",true ;
            Object of BufferedOutputStream := bos fos ;
            Object of DataOutputStream  :=dos bos ;
            for int i := 0 to ctr1  next 1  do 
            Begin
                Write to File  ino[i] ;
                Write to File  des[i] ;
                Write to File  String.valueOf roq[i]  ;
                Write to File  String.valueOf qoh[i]  ;
                Write to File  String.valueOf rol[i]  ;
                Write to File  "\n" ;
            end;
            close dos  ;
            close bos  ;
            close fos  ;

            File f2 :=new File "master2.dat" ;
            f1.delete  ;
            f2.renameTo f1 ;
            f2.delete  ;

        end;
    end;

    // counts the no. of records
    // -------------------------

    Returning non Parameterised method inoc  throws Exception of type integer
    Begin
        var ctr,ctr1,to : Integer;
        var s1 : String;
        if a 
            s1 :="sell.dat";
        else if b 
            s1 :="reorder.dat";
        else
            s1 :="master.dat";
        File f :=new File s1 ;
        if f.exists   
        Begin
            Onject of FileReader  := fr s1 ;
            Object of class StreamTokenizer := st  fr ;
            st.eolIsSignificant true ;
            while to! :=-1 
            Begin
                to :=st.nextToken  ;
                if to  :=-1 
                    break;
                if to  :=-3 
                Begin
                    if ctr  :=1 
                    Begin
                        ctr1++;
                        ctr :=ctr+1;
                    end;           
                    else if ctr  :=2 
                    Begin
                        if !b 
                            ctr :=1;
                        else
                            ctr :=ctr+1;
                    end;
                    else if ctr  :=3 
                        ctr :=1;
                end;
            end;           
            close fr  ;
        end;
        a :=false;
        b :=false;
        return ctr1;
    end;


    Non-Returning Parameterised method  update String in,int t,int ch  throws Exception 
    Begin
        var to,ro,ctr1,ctr2,k : Integer;
        
        varf :boolean ;

        File f1 :=new File "master.dat" ;
        if f1.exists   
        Begin
        Object of FileReader := fr "master.dat" ;
        Object of class StreamTokenizer := st fr ;
        st.eolIsSignificant true ;

            Object of FileOutputStream  := fos "master2.dat",true ;
            Object of BufferedOutputStream := bos fos ;
            Object of DataOutputStream  :=dos bos ;
        while to! :=-1 
        Begin
            if to  :=-3 
            Begin
                if ctr1  :=1 
                Begin
                    Write to File  st.sval.trim   ;
                    ctr1++;
                    if in.equalsIgnoreCase st.sval  
                    Begin
                        f :=true;
                        in :=st.sval;
                    end;
                end;
                else if ctr1  :=2 
                Begin
                    Write to File  st.sval.trim   ;
                    ctr1 :=1;
                end;
            end;
            if to  :=-2 
            Begin
                if ctr2  :=1 
                Begin
                    if f 
                    Begin
                        ro := int st.nval;
                        if t  :=2 
                            Write to File  String.valueOf ch .trim   ;
                        else
                            Write to File  String.valueOf st.nval .trim   ;
                    end;
                    else
                        Write to File  String.valueOf st.nval .trim   ;
                    ctr2++;
                end;
                else if ctr2  :=2 
                Begin
                    ctr2++;
                    if f 
                    Begin
                        if t  :=3 
                        Begin
                            Write to File  String.valueOf  st.nval+ro  .trim   ;
                        end;
                        else if t  :=4 
                        Begin
                            Write to File  String.valueOf  st.nval-ch  .trim   ;
                            Displayln  st.nval-ch  ;
                        end;
                        else
                            Write to File  String.valueOf st.nval .trim   ;
                    end;
                    else
                        Write to File  String.valueOf st.nval .trim   ;
                            
                end;

                else if ctr2  :=3 
                Begin
                    ctr2 :=1;
                    if f 
                    Begin
                        if t  :=1 
                        Begin
                            Write to File  String.valueOf ch .trim   ;
                        end;
                        else
                            Write to File  String.valueOf st.nval .trim   ;
                    end;
                    else
                        Write to File  String.valueOf st.nval .trim   ;
                end;
            end;
            if to  :=10 
            Begin
                if f 
                    f :=false;
                Write to File  "\n" ;
            end;
            to :=st.nextToken  ;
        end;

          close dos  ;
          close bos  ;
          close fos  ;

          close fr  ;
        File f2 :=new File "master2.dat" ;
        f1.delete  ;
        f2.renameTo f1 ;
        f2.delete  ;
        if t  :=3 
        Begin
        Object of FileOutputStream  := fo "reorder2.dat",true ;
        Object of BufferedOutputStream  := bo fo ;
        Object of DataOutputStream  := d bo ;
        var s : String;
        var t3 : integer;
        File f3 :=new File "reorder.dat" ;
        if f3.exists   
        Begin
            var ctr : Integer;
            var z,x : boolean;
            Object of FileReader  := fr1 "reorder.dat" ;
            Object of class StreamTokenizer := st; fr1 ;
            st1.eolIsSignificant true ;
            to :=st1.nextToken  ;
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if ctr  :=1 
                    Begin
                        ctr++;
                        d Write to File st1.sval.trim   ;
                        if in.equalsIgnoreCase st1.sval  
                        Begin
                            z :=true;
                            x :=true;
                        end;
                    end;
                    else if ctr  :=2 
                    Begin
                        if z 
                        Begin
                            Date d1 :=new Date  ;
                            s :=d1.toString  ;
                            s :=s.substring 4,7 +"00"+s.substring 8,10 +"00"+s.substring 24 ;
                            d Write to File s.trim   ;
                        end;
                        else
                            d Write to File st1.sval.trim   ;  
                        ctr++;
                    end;
                    else if ctr  :=3 
                    Begin
                        ctr :=1;
                        
                        if t3>2 
                            d Write to File "Excellent" ;
                        else if t3>1 
                            d Write to File "Good" ;
                        else if t3>0 
                            d Write to File "Average" ;
                        else
                            d Write to File "Poor" ;
                    end;
                end;
                if to  :=-2 
                Begin
                    if z 
                    Begin
                        d Write to File String.valueOf  t3 := int  st1.nval+1    ;
                    end;
                    else
                    Begin
                        d Write to File String.valueOf t3 := int st1.nval  ;
                    end;
                end;
                if to  :=10 
                Begin
                    d Write to File "\n" ;
                    if ctr  :=1 
                        z :=false;
                end;
                to :=st1.nextToken  ;
            end;
            if !x 
            Begin
                Date d3 :=new Date  ;
                s :=d3.toString  ;
                s :=s.substring 4,7 +"00"+s.substring 8,10 +"00"+s.substring 24 ;
                d Write to File in.trim   ;
                d Write to File s.trim   ;
                d Write to File String.valueOf  t3 := rotc in +1   .trim   ;
                if t3>2 
                    d Write to File "Excellent" ;
                else if t3>1 
                    d Write to File "Good" ;
                else if t3>0 
                    d Write to File "Average" ;
                else
                    d Write to File "Poor" ;
                d Write to File "\n" ;
            end;
            close fr1  ;
        end;
        else
        Begin
            Date d2 :=new Date  ;
            s :=d2.toString  ;
            s :=s.substring 4,7 +"00"+s.substring 8,10 +"00"+s.substring 24 ;
            d Write to File in.trim   ;
            d Write to File s.trim   ;
            d Write to File String.valueOf  t3 := rotc in +1   .trim   ;
            if t3>2 
                d Write to File "Excellent" ;
            else if t3>1 
                d Write to File "Good" ;
            else if t3>0 
                d Write to File "Average" ;
            else
                d Write to File "Poor" ;
            d Write to File "\n" ;
        end;
        close d  ;
        close bo  ;
        close fo  ;
        File f4 :=new File "reorder2.dat" ;
        f3.delete  ;
        f4.renameTo f3 ;
        f4.delete  ;
        end;
        end;
    end;

    Returning Parameterised method  rotc String in throws Exception of type Integer
    Begin
        File f1 :=new File "reorder.dat" ;
        var k: Integer;
        if f1.exists   
        Begin
            Object of FileReader  :=fr "reorder.dat" ;
            Object of class StreamTokenizer := st; fr ;
            st.eolIsSignificant true ;
            int to :=st.nextToken  ;
            var ctr : Integer;
            varf : boolean ;
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if ctr  :=2 
                        ctr++;
                    else if ctr  :=1 
                    Begin
                        if in.equalsIgnoreCase st.sval  
                            f :=true;
                        ctr++;
                    end;
                    else if ctr  :=3 
                        ctr :=1;
                end;
                if to  :=-2 
                    if f 
                        k := int st.nval;
                to :=st.nextToken  ;
            end;

            close fr  ;
        end;
        return k;
    end;
    //
    //check weather the input quantity qs  of item no. in  is less than t :=1 ->qoh t :=2 ->rol
    //-------------------------------------------------------------------------------------

    Returning Parameterised method  boolean qcheck String in,int qs,int t  throws Exception of type Boolean 
    Begin
        var to: Integer;
        var v,f : boolean;
        Object of File f1 :=new File "master.dat" ;
        if f1.exists   
        Begin
            Object of FileReader  := fr "master.dat" ;
            Object of class StreamTokenizer := st; fr ;
            st.eolIsSignificant true ;
            int ctr1 :=1,ctr2 :=1;
            //redo
            to :=st.nextToken  ;
            while to! :=-1 
            Begin
                if to  :=-3 
                Begin
                    if ctr1  :=1 
                    Begin
                        ctr1++;
                        if in.equalsIgnoreCase st.sval  
                            f :=true;
                    end;
                    else if ctr1  :=2 
                    Begin
                        ctr1 :=1;
                    end;
                end;
                if to  :=-2 
                Begin
                    if ctr2  :=1 
                    Begin
                        ctr2++;
                    end;
                    else if ctr2  :=2 
                    Begin
                        ctr2++;
                        if f 
                            if t  :=1 
                            Begin
                                if qs< :=st.nval 
                                    v :=true;
                            end;
                            else if t  :=2 
                            Begin
                                qs := int st.nval;
                            end;
                    end;
                    else if ctr2  :=3 
                    Begin
                        ctr2 :=1;
                        if f 
                            if t  :=2 
                                if qs< :=st.nval 
                                Begin
                                    v :=true;
                                end;
                    end;
                end;
                if to  :=10 
                    if f 
                        f :=false;
                to :=st.nextToken  ;
            end;
            fr.close  ;
        end;
        return v;
    end;
    Non-Returning non Parameterised method  sell   throws Exception
    Begin
        Object of BufferedReader := br;
        var v:boolean ;
        File f :=new File "master.dat" ;
        if f.exists   
        Begin
            Object of FileReader  := fr "master.dat" ;
            Object of class StreamTokenizer := st; fr ;
            st.eolIsSignificant true ;
            var in: String ;
            var to,qs : Integer;
            for ;; 
            Begin
                for ;; 
                Begin
                    v :=true;
                    Display "Enter Item Number eg. I001 : " ;
                    Input in :=br.readLine  .trim  ;
              
                    if in.length  ! :=4 
                    Begin
                      v :=false;
                      continue;
                    end;       
                    if in.charAt 0 ! :='I' && in.charAt 0 ! :='i' 
                        v :=false;
                    for int i := 1 to 4  next 1  do 
                    Begin
                        if ! in.charAt i > :='0' && in.charAt i < :='9'  
                            v :=false;
                    end;
                    v := validate in  && v ;
                    if !v 
                    Begin
                        Displayln "Invalid Item Number!" ;
                    end;
                    if v 
                        break;
                end;
                v :=false;
                for ;; 
                Begin
                    Display "Enter the Quatity Sold: " ;
                    Input qs :=Integer.parseInt br.readLine  .trim   ;
                    v :=qcheck in,qs,1 ; 
                    if !v 
                    Begin
                        Displayln "Insufficient quantity on hand!" ;
                        continue;
                    end;
                    break;
                end;
                Date d :=new Date  ;
                String s :=d.toString  ;
                s :=s.substring 4,7 +"00"+s.substring 8,10 +"00"+s.substring 24 ;
                Object of FileOutputStream  := fos := "sell.dat",true ;
                Object of BufferedOutputStream  :=bos fos ;
                Object of DataOutputStream  :=dos bos ;
                Write to File  s.trim   ;
                Write to File  in.trim   ;
                Write to File  String.valueOf qs .trim   ;
                Write to File  "\n" ;
                
                close dos  ;
                close bos  ;
                close fos  ;
                break;
            end;
            close fr  ;
            update in,4,qs ;

        end;
    end;
end;

