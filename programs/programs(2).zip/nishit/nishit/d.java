import java.io.*;
import java.util.*;
class d
{
	public static void main(String asd[])throws IOException
	{
		Date dt=new Date();
		System.out.println(dt);
	}
	//jan
	//feb
	//mar
	//apr
	//jun
	//jul
	//aug
	//sep
	//oct
	//nov
	//dec
}		