class decl
{
    public static void main(String args[])
    {
    int i=0;
    do
        {
        int y=0;
        y+=i;
        i++;
        System.out.println("y="+y);
     }while(i<3);
     }
     }
