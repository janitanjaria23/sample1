class inventoryDemo
{
    public static void main(String args[])throws Exception
    {
        inventory aa=new inventory();
        aa.menu();
    }
}
