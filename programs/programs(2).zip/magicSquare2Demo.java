class magicSquare2Demo
{
    public static void main(String args[])throws Exception
    {
        magicSquare2 m=new magicSquare2();
        m.title();
        m.menu();
    }
}
