import java.util.*;
class insitudiam
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int n=0;
        do
        {
            System.out.print("Enter the no. of rows: ");
            n=sc.nextInt();
        }while(n<0 || n>9 || n%2==0);
        for(int i=1,sp=0;i<=1;i++,sp+=2)
        {
            for(int k=1;k<)


        }
        for(int i=n/2+1,sp=1; i<=1;i++,sp+=2)
        {
           
        }






    }
}
