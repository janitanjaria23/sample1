import java.util.*;

class max
{
    public static void main(Strin args[])
    {
        Scanner sc=new Scanner(System.in);
        int a,b,c,m;
            System.out.print("Enter ant no. : ");
            a=sc.nextInt();
            System.out.print("Enter ant no. : ");
            b=sc.nextInt();
            System.out.print("Enter ant no. : ");
            c=sc.nextInt();
                if(a>b)
                    m=a
                else
                    m=b
                if(c>max)
                    m=c
                System.out.println("Maximum no. is: "+m);
    }
}
