import java.util.*;
import java.io.*;

class calc
{
    public static void main(String args[]) throws Exception
    {
        Scanner sc=new Scanner(System.in);
        DataInputStream dis=new DataInputStream(System.in);
        double a=0, b=0;
        String s="";
        System.out.print("Enter the sign: ");
        s=dis.readLine();
        if(s=="+")
            System.out.print("Enter the sign ");    
    }
}
