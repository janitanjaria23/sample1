class demo14
{
    public static void main(String args[])
    {
        int  x=10,y=2;
        double z=x-y+x/(y*Math.pow(x,2))*2;
        System.out.println(z);
    }
}
