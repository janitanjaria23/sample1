class inventoryDemo
{
    public static void main(String args[])throws Exception
    {
        inventory aa=new inventory();
        aa.menu();
        //aa.delete("i004");
        //aa.sort(aa.inoc());
        //aa.read(1);
        //aa.read(4);
        //aa.update("I005",4,45);
        //aa.read(1);
        //aa.sort(aa.inoc());
    }
}
