
class inventoryDemo
{
    public static void main(String args[])throws Exception
    {
        inventory aa=new inventory();
        aa.menu();
        //System.out.println(aa.inoe(0));
        //aa.repor(3,-1);
        //aa.delete("i004");
        //aa.sort(aa.inoc());
        //aa.read(1);
        //aa.read(4);
        //aa.update("I004",3,0);
        //aa.read(1);
        //aa.sort(aa.inoc());
    }
}
