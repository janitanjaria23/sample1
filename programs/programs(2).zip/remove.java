import java.io.*;
class remove
{
	public static void main(String args[])throws Exception
	{
		BufferedReader br = new BufferedReader( new InputStreamReader(System.in));
		int test = 0;
		String in="";
		test = Integer.parseInt(br.readLine().trim());
		
		
	}
}