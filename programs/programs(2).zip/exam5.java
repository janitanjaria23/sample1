class exam5
{
	public static void main (String[] args) 
	{
		int m=5,n=2;
		char c='A';
		String x="Hello";
		short m1=26;
		int n1=c+m1;
		System.out.println(x.charAt(3));
	}
}