import java.util.*;
class selectionsort
{
    public static void main(String args)
    {
    Scanner sc=new Scanner(System.in);
    int n=0;
    do
    {
    System.out.println();
    System.out.println();
    System.out.print("  Enter the no. of elements: ");
    n=sc.nextInt();
    }while(n<5 || n>15);


    // the selection sort

    for(int i=0;i<n)

    }

    }
