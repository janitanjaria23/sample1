/**
 * @(#)invertedPyramid.java
 *
 *
 * @author 
 * @version 1.00 2008/7/14
 */

import java.awt.*;

public class invertedPyramid extends java.applet.Applet {
    
    /** Initialization method that will be called after the applet is loaded
     *  into the browser.
     */
    public void init() {
        // TODO start asynchronous download of heavy resources
    }

    public void paint(Graphics g) {
        
    }
}