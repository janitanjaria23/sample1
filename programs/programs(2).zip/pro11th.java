class pro11th
{
	public static void main(String args[])throws Exception
	{
		{
			for(int i=0; i<120;i++)
			{
			System.out.print("=|");
			Thread.sleep(5);
			}
			
			for(int i=0; i<240;i++)
			{
			System.out.print(" ");
			
			}
			
			for(int i=0; i<80;i++)
			{
			System.out.print("*");
			Thread.sleep(10);
			}
			for(int i=0; i<33;i++)
			{			
			System.out.print("*");
			Thread.sleep(10);
			}
			System.out.print("            ");
			for(int i=0; i<35;i++)
			{
			System.out.print("*");
			Thread.sleep(10);
			}
			for(int i=0; i<33;i++)
			{
			System.out.print("*");
			Thread.sleep(10);
			}
			System.out.print(" INVENTORY  ");
			for(int i=0; i<35;i++)
			{
			System.out.print("*");
			Thread.sleep(10);
			}
			for(int i=0; i<33;i++)
			{
			System.out.print("*");
			Thread.sleep(10);
			}
			System.out.print("            ");
			for(int i=0; i<35;i++)
			{
			System.out.print("*");
			Thread.sleep(10);
			}
			for(int i=0; i<80;i++)
			{
			System.out.print("*");
			Thread.sleep(10);
			}
			
			for(int i=0; i<240;i++)
			{
			System.out.print(" ");
			
			}
			
			for(int i=0; i<120;i++)
			{
			System.out.print("=|");
			Thread.sleep(5);
			}
			
			System.out.println();
		}	
	}	
}			