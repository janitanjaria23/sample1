class demo1
{
    //public static void main(String args[])
    //{
        /*magic_square m=new magic_square();
        m.title();
	title t=new title();
    t.title1();*/
    int a()
    {
    int m=0;
    int[] i=new int[5];

        m++;
        return i;

    }
    
}
