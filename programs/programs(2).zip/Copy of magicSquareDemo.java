class magicSquareDemo
{
    public static void main(String args[])throws Exception
    {
        magicSquare m=new magicSquare();
        m.title();
        m.menu();
    }
}
