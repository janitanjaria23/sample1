import java.util.*;
class getcal1
{
    public static void main(String args[])

    {
    Date d=new Date();
    System.out.print(d);
    }
}
