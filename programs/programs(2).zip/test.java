class test
{
    public static void main(String args[])
    {
        int x=0;
        for(x=0; x<10;)
        x=x+1;
        System.out.println("This is x: "+x);
    }
}
