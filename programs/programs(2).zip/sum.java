import java.util.*;
class sum
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print(("Enter 1 st no. "+=(sc.nextInt()))+("Enter no. 2"(sc.nextInt()))); 
    
    }   
}
