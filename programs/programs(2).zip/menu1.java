void menu1()
    {
	int ch=0;
            Scanner sc=new Scanner(System.in);
            for(;;)
            {
                for(int i=0;i<39;i++)
                    System.out.print((char)(30)+""+(char)(31));
                System.out.println((char)(30));
            System.out.println((char)(16)+"\t\t\t*   *\t****\t*   *\t*   *\t\t\t      "+(char)(16));
            System.out.println((char)(17)+"\t\t\t** **\t*   \t**  *\t*   *\t\t\t      "+(char)(17));
            System.out.println((char)(16)+"\t\t\t* * *\t****\t* * *\t*   *\t\t\t      "+(char)(16));
            System.out.println((char)(17)+"\t\t\t*   *\t*   \t*  **\t*   *\t\t\t      "+(char)(17));
            System.out.println((char)(16)+"\t\t\t*   *\t****\t*   *\t*****\t\t\t      "+(char)(16));
	    