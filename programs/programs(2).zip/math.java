class math
{
    public static void main(String args[])
    {
        System.out.println(Math.abs(-5));
        System.out.println(Math.max(-5,7));
        System.out.println(Math.min(-5,8));
        System.out.println(Math.toRadians(30));
        System.out.println(Math.toDegrees(Math.PI));
        System.out.println(Math.floor(7.89));
        System.out.println(Math.ceil(7.89));
        System.out.println(Math.rint(-5.9999));
        System.out.println(Math.round(5.975));
     }}
//9428157737